# Ishaa Birthday Website 💗

A romantic static birthday website built with HTML, CSS, and JavaScript. No paid APIs or build tools are required.

## Before publishing
1. Open `index.html` in a text editor.
2. Find `const birthdayDate = "2026-12-15";` and change it to Ishaa's next birthday in `YYYY-MM-DD` format.
3. Save the file.
4. To add permanent photos, upload image files to this repository and edit the photo section in `index.html` to use those image paths. The on-page photo chooser only previews photos on the current device.
5. Optional music: add an audio file and set the `<audio id="bgMusic" loop>` element's `src` to the filename. Use music you have permission to use.

## Publish free with GitHub Pages
1. Sign in at https://github.com/
2. Create a **public** repository, for example `ishaa-birthday`.
3. Upload `index.html` and this README file.
4. Open repository **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
6. Wait a minute or two. GitHub will show the published address, usually `https://YOUR-USERNAME.github.io/ishaa-birthday/`.

## Notes
- This site is static and does not need a server or paid subscription.
- The countdown uses India Standard Time (UTC+05:30) and the date configured in the file.
- The photo upload controls are local previews; for images to appear for Ishaa too, add them to the repository and reference them in the code.
